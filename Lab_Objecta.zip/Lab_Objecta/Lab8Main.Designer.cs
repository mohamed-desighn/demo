﻿namespace Lab_Objecta
{
    partial class Lab8Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCarModel = new System.Windows.Forms.TextBox();
            this.txtYearMade = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnAccerelate = new System.Windows.Forms.Button();
            this.btnBreak = new System.Windows.Forms.Button();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblObj = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Car Model:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(90, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Year Made:";
            // 
            // txtCarModel
            // 
            this.txtCarModel.Location = new System.Drawing.Point(197, 112);
            this.txtCarModel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCarModel.Name = "txtCarModel";
            this.txtCarModel.Size = new System.Drawing.Size(112, 26);
            this.txtCarModel.TabIndex = 2;
            // 
            // txtYearMade
            // 
            this.txtYearMade.Location = new System.Drawing.Point(197, 184);
            this.txtYearMade.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtYearMade.Name = "txtYearMade";
            this.txtYearMade.Size = new System.Drawing.Size(112, 26);
            this.txtYearMade.TabIndex = 3;
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(90, 256);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(84, 29);
            this.btnCreate.TabIndex = 4;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnAccerelate
            // 
            this.btnAccerelate.Location = new System.Drawing.Point(245, 256);
            this.btnAccerelate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAccerelate.Name = "btnAccerelate";
            this.btnAccerelate.Size = new System.Drawing.Size(84, 29);
            this.btnAccerelate.TabIndex = 5;
            this.btnAccerelate.Text = "Accerelate";
            this.btnAccerelate.UseVisualStyleBackColor = true;
            this.btnAccerelate.Click += new System.EventHandler(this.btnAccerelate_Click);
            // 
            // btnBreak
            // 
            this.btnBreak.Location = new System.Drawing.Point(392, 256);
            this.btnBreak.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBreak.Name = "btnBreak";
            this.btnBreak.Size = new System.Drawing.Size(84, 29);
            this.btnBreak.TabIndex = 6;
            this.btnBreak.Text = "Break";
            this.btnBreak.UseVisualStyleBackColor = true;
            this.btnBreak.Click += new System.EventHandler(this.btnBreak_Click);
            // 
            // lblSpeed
            // 
            this.lblSpeed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lblSpeed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpeed.Location = new System.Drawing.Point(392, 96);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(195, 91);
            this.lblSpeed.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(90, 324);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Object Created: ";
            // 
            // lblObj
            // 
            this.lblObj.AutoSize = true;
            this.lblObj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblObj.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblObj.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObj.Location = new System.Drawing.Point(245, 323);
            this.lblObj.Name = "lblObj";
            this.lblObj.Size = new System.Drawing.Size(276, 23);
            this.lblObj.TabIndex = 9;
            this.lblObj.Text = "Instance of Object displayed here";
            // 
            // Lab8Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 394);
            this.Controls.Add(this.lblObj);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblSpeed);
            this.Controls.Add(this.btnBreak);
            this.Controls.Add(this.btnAccerelate);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.txtYearMade);
            this.Controls.Add(this.txtCarModel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Lab8Main";
            this.Text = "Car Object Demonstration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCarModel;
        private System.Windows.Forms.TextBox txtYearMade;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnAccerelate;
        private System.Windows.Forms.Button btnBreak;
        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblObj;
    }
}

