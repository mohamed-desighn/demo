﻿using System;
using System.Collections.Generic;
using System.Deployment.Internal;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Objecta
{
    internal class Employee
    {
        private int idNumber;
        private string name;
        private string postion;
        private string department;

        public int IDNumber
        {
            set { IDNumber = value; }
            get { return idNumber; }
        }

        public string Name
        {
            set { Name = value; }
            get { return name; }
        }

        public string Position
        {
            set { Position = value; }
            get { return postion; }
        }

        public string Department
        {
            set { Department = value; }
            get { return department; }
        }

        // one version of the constructor
        public Employee()
        {
            this.name = string.Empty;
            this.postion = string.Empty;
            this.IDNumber = 0;
            this.department = string.Empty;
        }

        //second version of the constructor, with 
        public Employee (string theName , int ID)
        {
            this.name = theName;
        }
    }
}
