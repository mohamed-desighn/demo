﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Instrumentation;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Objecta
{
    public class Car
    {
        private string model;
        private int year;
        private int speed;

        public int Year
        {
            get { return year; }
            set { Year = value; }
        }

        public string Model
        {
            get { return model; }
            set { Model = value; }
        }

        public int Speed {
            get {return speed; }
            set { speed = value; } 
        }
  
       public Car (int Year, string Model)
      {
            this.year = Year;
            this.model = Model;
            this.speed = 0;
       }

        public void Accerelate()
        {
            speed = speed + 5;
        }

        public void Brake()
        {
            speed = speed - 5;
        }

    }
}
