﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Objecta
{
    public partial class Lab8Main : Form
    {
        Car myCar;
        public Lab8Main()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
          myCar = new Car(int.Parse(txtYearMade.Text), txtCarModel.Text);

            lblObj.Text = "Model: " + myCar.Model + "  Year Made: " + myCar.Year;
        }

        private void btnAccerelate_Click(object sender, EventArgs e)
        {
            myCar.Accerelate();
            lblSpeed.Text = myCar.Speed.ToString();
        }

        private void btnBreak_Click(object sender, EventArgs e)
        {
            myCar.Brake();
            lblSpeed.Text = myCar.Speed.ToString();
        }
    }
}
